//jQuery to Open and Close Mobile Sidenav
$(document).ready(function()
{
    $(".open-mobilenav").click(function()
    {
        $(".mobilenav-container").show();
    });
    
    $(".close-mobilenav").click(function()
    {
        $(".mobilenav-container").hide();
    });
});

//jQuery to Open and Close Modal
$(document).ready(function()
{
    $(".open-modal").click(function()
    {
        $(".modal-container").toggle();
    });
    
    $(".close-modal").click(function()
    {
        $(".modal-container").toggle();
    });
});